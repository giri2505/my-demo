#!/usr/bin/env bash
# NetWorker Remediation Hub - Linux/macOS startup script
set -e
cd "$(dirname "$0")"

echo "========================================"
echo " NetWorker Remediation Hub"
echo "========================================"

# Install dependencies if needed
if ! python3 -c "import flask" 2>/dev/null; then
    echo "Installing dependencies..."
    pip3 install flask flask-cors paramiko pywinrm
fi

# Optional: set Anthropic API key if you prefer env var over Settings UI
# export ANTHROPIC_API_KEY=sk-ant-api03-...

echo "Starting API server on http://localhost:5050"
echo "Open dashboard.html in your browser OR visit http://localhost:5050"
echo ""
python3 dashboard_api.py
