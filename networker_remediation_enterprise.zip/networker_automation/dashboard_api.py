"""
NetWorker Remediation Dashboard - Flask API Backend
Exposes REST endpoints that the HTML dashboard calls.
All automation steps run as real Python - this is NOT a simulation.

Run:
    pip install flask flask-cors paramiko pywinrm
    python dashboard_api.py

Then open dashboard.html in your browser.
"""

import json
import os
import threading
import time
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

# Import automation steps
from step1_parse_ticket     import parse_from_csv, parse_single
from step2_reachability     import ping_host
from step3_identify_os      import identify_os
from step4_login            import login, ssh_login, winrm_login, run_ssh_command, run_winrm_command
from step5_service_check    import check_services, LINUX_SERVICES, WINDOWS_SERVICES
from step6_disk_check       import check_disk
from step7_retrigger_backup import retrigger_backup
from step8_close_notes      import build_close_note

# AI Analysis module - Azure AI Foundry (primary) + Anthropic (fallback)
try:
    from ai_analysis import (configure as ai_configure,
                              triage_ticket, generate_rca, detect_patterns,
                              generate_ai_close_notes, recommend_manual_steps,
                              ai_available, active_provider, active_model,
                              test_connection as ai_test_connection)
    AI_MODULE_LOADED = True
except ImportError:
    AI_MODULE_LOADED = False
    def ai_configure(cfg): pass
    def triage_ticket(t): return t
    def generate_rca(t): return t
    def detect_patterns(ts): return {}
    def generate_ai_close_notes(t): return ""
    def recommend_manual_steps(t): return []
    def ai_available(): return False
    def active_provider(): return "none"
    def active_model(): return "none"
    def ai_test_connection(): return {"ok": False, "message": "ai_analysis.py not found"}

def _inject_ai_config():
    """Push latest config into ai_analysis before each AI call."""
    ai_configure(load_config())

app = Flask(__name__)
CORS(app)

# ---------------------------------------------------------------------------
# In-memory state
# ---------------------------------------------------------------------------
tickets: dict      = {}   # ticket_id -> ticket dict
run_logs: dict     = {}   # ticket_id -> list of log lines
running_jobs: dict = {}   # ticket_id -> True if actively running

# Password-prompt state: pipeline thread blocks on this event until the
# dashboard user submits a password via POST /api/tickets/<tid>/provide-password
_password_events: dict = {}   # ticket_id -> threading.Event
_pending_passwords: dict = {} # ticket_id -> password string (cleared after use)

# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
# CONFIG_DIR env var lets Docker mount a persistent volume for settings.
# Falls back to the app directory if not set (local / non-Docker usage).
_CONFIG_DIR = os.environ.get('CONFIG_DIR', os.path.dirname(os.path.abspath(__file__)))
CONFIG_FILE  = os.path.join(_CONFIG_DIR, 'dashboard_config.json')

def load_config() -> dict:
    defaults = {
        'username':          '',
        # Linux SSH auth method:
        #   key_file  - SSH private key file path (recommended for service accounts)
        #   key_text  - paste raw private key content
        #   agent     - SSH agent (ssh-add)
        #   gssapi    - Kerberos/GSSAPI (kinit first)
        #   jump_host - bastion tunnel
        #   vault     - HashiCorp Vault OTP
        #   password  - plain username + password
        #   prompt    - password entered live in dashboard at run time
        'auth_method':       'key_file',
        'key_path':          '',
        'key_text':          '',
        'password':          '',
        # Jump host
        'jump_host':         '',
        'jump_user':         '',
        'jump_password':     '',
        'jump_key_path':     '',
        # Vault
        'vault_addr':        '',
        'vault_token':       '',
        'vault_role':        '',
        # Windows WinRM
        # ntlm      - PAM/domain account (same creds as RDP, port 5985)
        # kerberos  - AD SSO (kinit svc@DOMAIN.COM first)
        # credssp   - double-hop delegation
        # certificate - client cert
        # prompt    - password entered live in dashboard at run time
        'winrm_auth':        'ntlm',
        'winrm_ssl':         False,
        'cert_pem':          '',
        'cert_key_pem':      '',
        # Azure AI Foundry (primary AI provider)
        'azure_endpoint':    '',
        'azure_deployment':  '',
        'azure_api_key':     '',
        'azure_api_version': '2024-08-01-preview',
        # Anthropic Claude (fallback AI provider)
        'anthropic_api_key': os.environ.get('ANTHROPIC_API_KEY', ''),
        # Pipeline options
        'dry_run':           False,
        'min_disk_gb':       10,
        'linux_services':    LINUX_SERVICES,
        'windows_services':  WINDOWS_SERVICES,
        # AI feature flags
        'ai_triage_enabled': True,
        'ai_rca_enabled':    True,
    }
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            saved = json.load(f)
        defaults.update(saved)
    return defaults

def save_config(cfg: dict):
    with open(CONFIG_FILE, 'w') as f:
        json.dump(cfg, f, indent=2)

def log(ticket_id: str, msg: str):
    """Append a timestamped log line for a ticket."""
    ts   = datetime.now().strftime('%H:%M:%S')
    line = f"[{ts}] {msg}"
    run_logs.setdefault(ticket_id, []).append(line)
    print(f"[{ticket_id}] {msg}")

def _build_auth_kwargs(cfg: dict) -> dict:
    """Build the auth_kwargs dict that every step function accepts."""
    return dict(
        auth_method   = cfg.get('auth_method', 'password'),
        password      = cfg.get('password') or None,
        key_path      = cfg.get('key_path') or None,
        key_text      = cfg.get('key_text') or None,
        jump_host     = cfg.get('jump_host') or None,
        jump_user     = cfg.get('jump_user') or None,
        jump_password = cfg.get('jump_password') or None,
        jump_key_path = cfg.get('jump_key_path') or None,
        vault_addr    = cfg.get('vault_addr') or None,
        vault_token   = cfg.get('vault_token') or None,
        vault_role    = cfg.get('vault_role') or None,
        winrm_auth    = cfg.get('winrm_auth', 'ntlm'),
        use_ssl       = cfg.get('winrm_ssl', False),
        cert_pem      = cfg.get('cert_pem') or None,
        cert_key_pem  = cfg.get('cert_key_pem') or None,
    )

# ---------------------------------------------------------------------------
# Ticket CRUD
# ---------------------------------------------------------------------------

@app.route('/api/tickets', methods=['GET'])
def get_tickets():
    return jsonify(list(tickets.values()))


@app.route('/api/tickets', methods=['POST'])
def add_ticket():
    data = request.json
    tid  = data.get('ticket_id', '').strip()
    if not tid:
        return jsonify({'error': 'ticket_id required'}), 400
    if tid in tickets:
        return jsonify({'error': f'Ticket {tid} already exists'}), 409
    t = {
        'ticket_id':   tid,
        'nw_server':   data.get('nw_server', '').strip(),
        'client':      data.get('client', '').strip(),
        'os_type':     data.get('os_type', 'Unknown'),
        'description': data.get('description', ''),
        'status':      'New',
        'created':     datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'updated':     datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
        'steps_done':  0,
    }
    tickets[tid]  = t
    run_logs[tid] = []
    return jsonify(t), 201


@app.route('/api/tickets/import', methods=['POST'])
def import_csv():
    """Accept CSV file upload and parse tickets."""
    if 'file' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400
    f        = request.files['file']
    tmp_path = f'/tmp/snow_import_{int(time.time())}.csv'
    f.save(tmp_path)
    try:
        parsed = parse_from_csv(tmp_path)
        added  = 0
        for t in parsed:
            tid = t['ticket_id']
            if tid not in tickets:
                t.update({
                    'status':     'New',
                    'created':    datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'updated':    datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                    'steps_done': 0,
                })
                tickets[tid]  = t
                run_logs[tid] = []
                added += 1
        os.remove(tmp_path)
        return jsonify({'imported': added, 'total': len(parsed)})
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/tickets/<tid>', methods=['DELETE'])
def delete_ticket(tid):
    tickets.pop(tid, None)
    run_logs.pop(tid, None)
    running_jobs.pop(tid, None)
    _password_events.pop(tid, None)
    _pending_passwords.pop(tid, None)
    return jsonify({'deleted': tid})


@app.route('/api/tickets/<tid>/logs', methods=['GET'])
def get_logs(tid):
    return jsonify(run_logs.get(tid, []))


@app.route('/api/tickets/<tid>/close-notes', methods=['GET'])
def get_close_notes(tid):
    t = tickets.get(tid)
    if not t:
        return jsonify({'error': 'Not found'}), 404
    return jsonify({'close_notes': t.get('close_notes', 'Not yet generated.')})


# ---------------------------------------------------------------------------
# Config routes
# ---------------------------------------------------------------------------

@app.route('/api/config', methods=['GET'])
def get_config():
    cfg = load_config()
    # Mask secrets - return placeholder so client knows a value is saved
    for key in ('password', 'key_text', 'jump_password', 'vault_token',
                'azure_api_key', 'anthropic_api_key'):
        if cfg.get(key):
            cfg[key] = '__saved__'
    return jsonify(cfg)


@app.route('/api/config', methods=['POST'])
def set_config():
    cfg  = load_config()
    data = request.json
    # Don't overwrite saved secrets with placeholder
    for key in ('password', 'key_text', 'jump_password', 'vault_token',
                'azure_api_key', 'anthropic_api_key'):
        if data.get(key) == '__saved__':
            data.pop(key)
    cfg.update({k: v for k, v in data.items() if v is not None})
    save_config(cfg)
    return jsonify({'saved': True})


# ---------------------------------------------------------------------------
# Password-prompt endpoint
# ---------------------------------------------------------------------------

@app.route('/api/tickets/<tid>/provide-password', methods=['POST'])
def provide_password(tid):
    """
    Dashboard user submits a password while the pipeline is paused waiting.
    The background thread is unblocked and picks up the password from
    _pending_passwords[tid].
    """
    data = request.json or {}
    pwd  = data.get('password', '').strip()
    if not pwd:
        return jsonify({'error': 'password required'}), 400
    if tid not in _password_events:
        return jsonify({'error': 'No pipeline waiting for a password on this ticket'}), 404

    _pending_passwords[tid] = pwd
    _password_events[tid].set()          # unblock the pipeline thread
    log(tid, '  [prompt] Password received from dashboard - resuming...')
    return jsonify({'ok': True})


@app.route('/api/tickets/<tid>/password-status', methods=['GET'])
def password_status(tid):
    """
    Poll this to know if the pipeline is currently waiting for a password input.
    Returns: { waiting: bool }
    """
    t = tickets.get(tid)
    waiting = bool(
        t and
        t.get('status') == 'WaitingPassword' and
        tid in _password_events and
        not _password_events[tid].is_set()
    )
    return jsonify({'waiting': waiting, 'status': t.get('status') if t else None})


# ---------------------------------------------------------------------------
# Connection test
# ---------------------------------------------------------------------------

@app.route('/api/test-connection', methods=['POST'])
def test_connection():
    """Quick connectivity + login test using saved config."""
    cfg      = load_config()
    username = cfg.get('username', '')
    if not username:
        return jsonify({'ok': False, 'error': 'No username configured. Go to Settings first.'})

    sample = next((t for t in tickets.values()), None)
    if not sample:
        return jsonify({'ok': True, 'message': 'Config saved. Add a ticket to test a real connection.'})

    client = sample['client']
    if not ping_host(client, retries=1):
        return jsonify({'ok': False, 'error': f'Cannot reach {client} - check network/firewall.'})

    auth_method = cfg.get('auth_method', 'password')
    if auth_method == 'prompt':
        return jsonify({'ok': True, 'message': 'Auth method is "prompt" - password will be requested at run time.'})

    auth_kw  = _build_auth_kwargs(cfg)
    test_t   = dict(sample)
    login(test_t, username, **auth_kw)
    conn = test_t.pop('_conn', None)
    if conn:
        try: conn.close()
        except: pass
    if test_t.get('step4_status') == 'PASS':
        return jsonify({'ok': True, 'message': test_t['step4_note']})
    return jsonify({'ok': False, 'error': test_t.get('step4_note', 'Login failed')})


# ---------------------------------------------------------------------------
# Pipeline runner
# ---------------------------------------------------------------------------

def _wait_for_password(tid: str, timeout: int = 300) -> str | None:
    """
    Block the pipeline thread until the dashboard user supplies a password
    (via POST /api/tickets/<tid>/provide-password) or timeout expires.
    Returns the password string, or None on timeout.
    """
    event = threading.Event()
    _password_events[tid]  = event
    _pending_passwords.pop(tid, None)

    t = tickets[tid]
    t['status'] = 'WaitingPassword'
    t['updated'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    log(tid, '  [prompt] Waiting for password input in dashboard...')

    got_it = event.wait(timeout=timeout)
    _password_events.pop(tid, None)

    if got_it:
        pwd = _pending_passwords.pop(tid, None)
        t['status'] = 'Running'
        return pwd
    else:
        log(tid, f'  [prompt] ✗ Timed out waiting for password after {timeout}s')
        _pending_passwords.pop(tid, None)
        return None


def run_ticket_pipeline(tid: str):
    """Background thread - runs all 8 steps for one ticket."""
    t = tickets.get(tid)
    if not t:
        return

    cfg      = load_config()
    username = cfg.get('username', '')
    dry_run  = cfg.get('dry_run', False)

    auth_kwargs = _build_auth_kwargs(cfg)

    # Handle "prompt" auth method - pause here and wait for dashboard input
    if cfg.get('auth_method') == 'prompt' or cfg.get('winrm_auth') == 'prompt':
        running_jobs[tid] = True
        t['status']      = 'Running'
        t['steps_done']  = 0
        t['updated']     = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        run_logs[tid]    = []

        log(tid, f'Step 4 (login) requires a password - prompting...')
        log(tid, f'  Host: {t["client"]} | User: {username}')

        pwd = _wait_for_password(tid, timeout=300)
        if not pwd:
            t['status']       = 'Failed'
            t['step4_status'] = 'FAIL'
            t['step4_note']   = 'Password prompt timed out (5 min)'
            running_jobs[tid] = False
            return

        # Inject the live password and switch to password auth
        auth_kwargs['password']    = pwd
        auth_kwargs['auth_method'] = 'password'
        if cfg.get('winrm_auth') == 'prompt':
            auth_kwargs['winrm_auth'] = 'ntlm'
        log(tid, '  [prompt] Password accepted - continuing pipeline')
    else:
        running_jobs[tid] = True
        t['status']      = 'Running'
        t['steps_done']  = 0
        t['updated']     = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        run_logs[tid]    = []

    def update(step_num, status, note=''):
        t[f'step{step_num}_status'] = status
        t[f'step{step_num}_note']   = note
        t['steps_done'] = step_num
        t['updated']    = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

    try:
        # Step 1: Parse
        log(tid, 'Step 1: Parsing ticket fields...')
        t['step1_status'] = 'PASS'
        t['step1_note']   = f"Server: {t['nw_server']} | Client: {t['client']}"
        t['steps_done']   = 1
        log(tid, f"  + NW Server: {t['nw_server']}  Client: {t['client']}")

        # AI Triage
        _inject_ai_config()
        if cfg.get('ai_triage_enabled', True) and ai_available():
            log(tid, 'AI: Running pre-remediation triage...')
            try:
                triage_ticket(t)
                if t.get('ai_priority'):
                    log(tid, f"  AI Risk: {t.get('ai_risk_score')}/10 | "
                             f"Priority: {t.get('ai_priority')} | "
                             f"Predicted: {t.get('ai_predicted_cause', 'unknown')}")
            except Exception as ae:
                log(tid, f"  AI triage skipped: {ae}")

        # Step 2: Reachability
        log(tid, f"Step 2: Pinging {t['client']}...")
        reachable = ping_host(t['client'])
        t['reachable'] = reachable
        if reachable:
            update(2, 'PASS', f"{t['client']} is reachable")
            log(tid, '  + Host is reachable')
        else:
            update(2, 'FAIL', f"Host {t['client']} unreachable - ICMP timeout")
            t['status'] = 'Unreachable'
            log(tid, '  x Host UNREACHABLE - stopping')
            _finish(t, tid)
            return

        # Step 3: OS identification
        log(tid, f"Step 3: Identifying OS for {t['client']}...")
        os_type    = identify_os(t['client'], t.get('os_type', 'Unknown'))
        t['os_type'] = os_type
        update(3, 'PASS', f"Identified as {os_type}")
        log(tid, f"  + OS: {os_type}")

        # Step 4: Login — connection stored in t['_conn'], kept alive for steps 5 & 6
        log(tid, f"Step 4: Logging in as {username}...")
        login(t, username, **auth_kwargs)
        if t.get('step4_status') != 'PASS':
            t.pop('_conn', None)
            t['status'] = 'Failed'
            log(tid, f"  x Login failed: {t.get('step4_note')}")
            _finish(t, tid)
            return
        update(4, 'PASS', t.get('step4_note', ''))
        log(tid, '  + Login successful')

        # Step 5: Service check — reuses t['_conn'] from step 4
        log(tid, 'Step 5: Checking backup services...')
        check_services(t, username, **auth_kwargs)
        s5 = t.get('step5_status', 'FAIL')
        log(tid, f"  {'+ ' if s5 == 'PASS' else '~ '} Services: {t.get('step5_note', '')}")
        for svc in t.get('step5_services', []):
            icon = '+' if svc['action'] == 'none' else '~' if svc['action'] == 'restarted' else 'x'
            log(tid, f"    {icon} {svc['service']}: {svc['state']}")

        # Step 6: Disk space — reuses t['_conn'] from step 4/5
        log(tid, 'Step 6: Checking disk space...')
        check_disk(t, username, **auth_kwargs)
        s6 = t.get('step6_status', 'OK')
        log(tid, f"  {'RED' if s6 == 'RED' else '+ '} Disk: {t.get('step6_note', '')}")
        for d in t.get('step6_disk', []):
            log(tid, f"    {'RED' if d['flag']=='RED' else '+ '} {d['path']}: {d['detail']}")

        # Close the shared connection — steps 5 & 6 are done with the client
        conn = t.pop('_conn', None)
        if conn and t.get('_conn_type') == 'ssh' and hasattr(conn, 'close'):
            try: conn.close()
            except: pass
        t.pop('_conn_type', None)

        # Step 7: Retrigger backup
        if t.get('step5_status') == 'FAIL':
            t['step7_status'] = 'SKIPPED'
            t['step7_note']   = 'Skipped - service restart failed'
            log(tid, 'Step 7: SKIPPED - service restart failed')
        else:
            log(tid, f"Step 7: Retriggering backup on {t['nw_server']}...")
            retrigger_backup(t, username, dry_run=dry_run, **auth_kwargs)
            s7 = t.get('step7_status', 'FAIL')
            log(tid, f"  {'+' if s7 == 'PASS' else 'x'} Retrigger: {t.get('step7_note', '')}")
        t['steps_done'] = 7

        # Step 8: Close notes
        log(tid, 'Step 8: Generating close notes...')
        t['close_notes'] = build_close_note(t)
        t['steps_done']  = 8
        log(tid, '  + Close notes generated')

        # AI RCA
        if cfg.get('ai_rca_enabled', True) and ai_available():
            log(tid, 'AI: Running root cause analysis...')
            try:
                generate_rca(t)
                if t.get('ai_root_cause'):
                    log(tid, f"  AI RCA: {t.get('ai_root_cause')} "
                             f"(confidence: {t.get('ai_confidence', '?')})")
                ai_note = generate_ai_close_notes(t)
                if ai_note:
                    t['ai_close_notes'] = ai_note
                if t.get('status') == 'Failed':
                    steps = recommend_manual_steps(t)
                    t['ai_manual_steps'] = steps
                    if steps:
                        log(tid, f"  AI: {len(steps)} manual steps suggested")
            except Exception as ae:
                log(tid, f"  AI RCA skipped: {ae}")

        _finish(t, tid)

    except Exception as e:
        import traceback
        log(tid, f'  x UNEXPECTED ERROR: {e}')
        log(tid, traceback.format_exc().split('\n')[-2])
        t['status']       = 'Failed'
        t['error']        = str(e)
        running_jobs[tid] = False


def _finish(t: dict, tid: str):
    """Set final ticket status after pipeline completes."""
    if t['status'] not in ('Unreachable', 'Failed'):
        s7 = t.get('step7_status', 'SKIPPED')
        s6 = t.get('step6_status', 'PASS')
        s5 = t.get('step5_status', 'PASS')
        if s7 == 'PASS' and s5 == 'PASS' and s6 != 'RED':
            t['status'] = 'Remediated'
        elif s7 == 'PASS' and s6 == 'RED':
            t['status'] = 'Partial'
        elif s7 == 'FAIL':
            t['status'] = 'Failed'
        else:
            t['status'] = 'Remediated'
    t['updated']      = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    running_jobs[tid] = False
    log(tid, f"Pipeline complete - Final status: {t['status']}")


# ---------------------------------------------------------------------------
# Run endpoints
# ---------------------------------------------------------------------------

@app.route('/api/tickets/<tid>/run', methods=['POST'])
def run_ticket(tid):
    if tid not in tickets:
        return jsonify({'error': 'Ticket not found'}), 404
    if running_jobs.get(tid):
        return jsonify({'error': 'Already running'}), 409
    cfg = load_config()
    if not cfg.get('username'):
        return jsonify({'error': 'Service account not configured. Go to Settings tab.'}), 400
    thread = threading.Thread(target=run_ticket_pipeline, args=(tid,), daemon=True)
    thread.start()
    return jsonify({'started': tid})


@app.route('/api/run-all', methods=['POST'])
def run_all():
    new_tickets = [t for t in tickets.values() if t['status'] == 'New']
    started = []
    for t in new_tickets:
        tid = t['ticket_id']
        if not running_jobs.get(tid):
            thread = threading.Thread(target=run_ticket_pipeline, args=(tid,), daemon=True)
            thread.start()
            started.append(tid)
    return jsonify({'started': started})


# ---------------------------------------------------------------------------
# AI endpoints
# ---------------------------------------------------------------------------

@app.route('/api/ai/status', methods=['GET'])
def ai_status():
    """Check AI provider status - Azure Foundry first, Anthropic fallback."""
    _inject_ai_config()
    return jsonify({
        'available': ai_available(),
        'provider':  active_provider(),
        'model':     active_model(),
    })


@app.route('/api/ai/test', methods=['POST'])
def ai_test():
    """Test the configured AI provider (Azure Foundry or Anthropic)."""
    _inject_ai_config()
    result = ai_test_connection()
    return jsonify(result)


@app.route('/api/ai/triage/<tid>', methods=['POST'])
def ai_triage(tid):
    """Run AI triage on a single ticket."""
    t = tickets.get(tid)
    if not t:
        return jsonify({'error': 'Ticket not found'}), 404
    _inject_ai_config()
    try:
        triage_ticket(t)
        return jsonify({
            'ai_risk_score':      t.get('ai_risk_score'),
            'ai_predicted_cause': t.get('ai_predicted_cause'),
            'ai_priority':        t.get('ai_priority'),
            'ai_triage_note':     t.get('ai_triage_note'),
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/ai/rca/<tid>', methods=['POST'])
def ai_rca(tid):
    """Run AI root cause analysis on a completed ticket."""
    t = tickets.get(tid)
    if not t:
        return jsonify({'error': 'Ticket not found'}), 404
    _inject_ai_config()
    try:
        generate_rca(t)
        steps = recommend_manual_steps(t) if t.get('status') == 'Failed' else []
        t['ai_manual_steps'] = steps
        ai_note = generate_ai_close_notes(t)
        if ai_note:
            t['ai_close_notes'] = ai_note
        return jsonify({
            'ai_root_cause':             t.get('ai_root_cause'),
            'ai_remediation_summary':    t.get('ai_remediation_summary'),
            'ai_preventive_actions':     t.get('ai_preventive_actions', []),
            'ai_confidence':             t.get('ai_confidence'),
            'ai_requires_manual_review': t.get('ai_requires_manual_review'),
            'ai_manual_steps':           steps,
            'ai_close_notes':            t.get('ai_close_notes', ''),
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/ai/patterns', methods=['POST'])
def ai_patterns():
    """Detect patterns across all tickets."""
    _inject_ai_config()
    try:
        result = detect_patterns(list(tickets.values()))
        return jsonify(result)
    except Exception as e:
        return jsonify({'error': str(e)}), 500


@app.route('/api/ai/manual-steps/<tid>', methods=['GET'])
def ai_manual_steps(tid):
    """Get AI-recommended manual troubleshooting steps for a failed ticket."""
    t = tickets.get(tid)
    if not t:
        return jsonify({'error': 'Ticket not found'}), 404
    _inject_ai_config()
    steps = recommend_manual_steps(t)
    t['ai_manual_steps'] = steps
    return jsonify({'steps': steps})


@app.route('/api/export', methods=['GET'])
def export_results():
    """Export all ticket results as JSON."""
    return jsonify(list(tickets.values()))


@app.route('/')
def serve_dashboard():
    return send_from_directory(os.path.dirname(__file__), 'dashboard.html')


if __name__ == '__main__':
    print("=" * 55)
    print(" NetWorker Remediation Dashboard API")
    print(" http://localhost:5050")
    print("=" * 55)
    app.run(host='0.0.0.0', port=5050, debug=False)
