"""
Step 5: Service Health Check & Restart
Checks if required backup services are running. Restarts any stopped services.
Configure SERVICES_TO_CHECK below once you confirm the service names.

Usage: python step5_service_check.py --client app-srv-42 --os Linux --user svc_backup --key ~/.ssh/id_rsa
       python step5_service_check.py --file parsed_tickets.json --user svc_backup --key ~/.ssh/id_rsa

Dependencies: pip install paramiko pywinrm
"""

import argparse
import json
import sys
from step4_login import ssh_login, winrm_login, run_ssh_command, run_winrm_command


# ── CONFIGURE THESE once you confirm service names ─────────────────────────
LINUX_SERVICES = [
    'nsrexecd',       # NetWorker client daemon
    'nsrd',           # NetWorker server daemon (if server role)
    # 'nsrindexd',    # uncomment as needed
    # 'nsrmmdbd',
]

WINDOWS_SERVICES = [
    'NetWorker Remote Exec Service',
    'Legato NetWorker',
    # Add more as confirmed
]
# ───────────────────────────────────────────────────────────────────────────


def check_linux_service(conn, service: str) -> str:
    """Returns 'running', 'stopped', or 'not_found'."""
    stdout, stderr, rc = run_ssh_command(conn, f'systemctl is-active {service} 2>/dev/null || service {service} status 2>/dev/null | grep -i running')
    if 'active' in stdout or 'running' in stdout:
        return 'running'
    if rc == 0:
        return 'running'
    # Check if service exists at all
    _, _, exists_rc = run_ssh_command(conn, f'systemctl list-unit-files {service}.service 2>/dev/null | grep {service}')
    if exists_rc != 0:
        return 'not_found'
    return 'stopped'


def restart_linux_service(conn, service: str) -> bool:
    """Restart a Linux service. Returns True on success."""
    stdout, stderr, rc = run_ssh_command(conn, f'sudo systemctl restart {service} && systemctl is-active {service}')
    if rc == 0 and 'active' in stdout:
        return True
    # Fallback to legacy init
    stdout2, stderr2, rc2 = run_ssh_command(conn, f'sudo service {service} restart')
    return rc2 == 0


def check_windows_service(session, service: str) -> str:
    """Returns 'running', 'stopped', or 'not_found'."""
    ps_cmd = f'Get-Service -Name "{service}" -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Status'
    stdout, stderr, rc = run_winrm_command(session, ps_cmd)
    if 'Running' in stdout:
        return 'running'
    if 'Stopped' in stdout:
        return 'stopped'
    return 'not_found'


def restart_windows_service(session, service: str) -> bool:
    """Restart a Windows service. Returns True on success."""
    ps_cmd = f'Start-Service -Name "{service}" -ErrorAction Stop; (Get-Service -Name "{service}").Status'
    stdout, stderr, rc = run_winrm_command(session, ps_cmd)
    return rc == 0 and 'Running' in stdout


def check_services(ticket: dict, username: str, **auth_kwargs) -> dict:
    """
    Check all services for a ticket. Connects, checks, restarts if stopped.
    """
    hostname = ticket['client']
    os_type  = ticket.get('os_type', 'Linux')
    services = LINUX_SERVICES if os_type == 'Linux' else WINDOWS_SERVICES

    # Establish connection
    if os_type == 'Linux':
        conn = ssh_login(hostname, username, **auth_kwargs)
    else:
        conn = winrm_login(hostname, username, auth_method=auth_kwargs.get("winrm_auth","ntlm"), password=auth_kwargs.get("password"))

    if not conn:
        ticket['step5_status'] = 'FAIL'
        ticket['step5_note']   = 'Could not connect to host for service check'
        return ticket

    results = []
    overall = 'PASS'

    for svc in services:
        if os_type == 'Linux':
            state = check_linux_service(conn, svc)
        else:
            state = check_windows_service(conn, svc)

        if state == 'running':
            print(f"[STEP 5] ✓ {svc} is running on {hostname}")
            results.append({'service': svc, 'state': 'running', 'action': 'none'})

        elif state == 'stopped':
            print(f"[STEP 5] ⚠ {svc} is STOPPED on {hostname} — attempting restart...")
            if os_type == 'Linux':
                ok = restart_linux_service(conn, svc)
            else:
                ok = restart_windows_service(conn, svc)

            if ok:
                print(f"[STEP 5] ✓ {svc} restarted successfully")
                results.append({'service': svc, 'state': 'restarted', 'action': 'restarted'})
            else:
                print(f"[STEP 5] ✗ Failed to restart {svc}")
                results.append({'service': svc, 'state': 'restart_failed', 'action': 'restart_failed'})
                overall = 'FAIL'

        else:
            print(f"[STEP 5] ⚠ {svc} not found on {hostname} — skipping")
            results.append({'service': svc, 'state': 'not_found', 'action': 'skipped'})

    if os_type == 'Linux' and hasattr(conn, 'close'):
        conn.close()

    ticket['step5_status']   = overall
    ticket['step5_services'] = results
    restarted = [r['service'] for r in results if r['action'] == 'restarted']
    failed    = [r['service'] for r in results if r['action'] == 'restart_failed']
    note_parts = []
    if restarted: note_parts.append(f"Restarted: {', '.join(restarted)}")
    if failed:    note_parts.append(f"Restart failed: {', '.join(failed)}")
    if not note_parts: note_parts.append('All services OK')
    ticket['step5_note'] = ' | '.join(note_parts)

    return ticket


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Step 5: Service check & restart')
    parser.add_argument('--client',   help='Single client hostname')
    parser.add_argument('--os',       help='Windows or Linux', default='Linux')
    parser.add_argument('--user',     required=True, help='Service account username')
    parser.add_argument('--key',      help='SSH private key path')
    parser.add_argument('--password', help='Password')
    parser.add_argument('--file',     help='Tickets JSON', default='parsed_tickets.json')
    parser.add_argument('--output',   help='Output JSON', default='parsed_tickets.json')
    args = parser.parse_args()

    if args.client:
        ticket = {'ticket_id': 'TEST', 'client': args.client, 'os_type': args.os, 'reachable': True}
        check_services(ticket, args.user, auth_method="password", password=args.password, key_path=args.key)
        print(f"Status: {ticket['step5_status']} — {ticket['step5_note']}")
    else:
        with open(args.file) as f:
            tickets = json.load(f)
        for t in tickets:
            if t.get('step4_status') == 'PASS':
                check_services(t, args.user, key_path=args.key, password=args.password)
            else:
                t['step5_status'] = 'SKIPPED'
                t['step5_note']   = 'Skipped — login failed'
        with open(args.output, 'w') as f:
            json.dump(tickets, f, indent=2)
        print(f"[STEP 5] Saved to {args.output}")
