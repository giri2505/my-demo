"""
Step 5: Service Health Check & Restart
Checks if required backup services are running. Restarts any stopped services.

KEY DESIGN: This step reuses the live connection stored in ticket['_conn']
from step 4, so no second login is needed. It only opens a new connection
if called standalone (CLI mode) or if ticket['_conn'] is absent.

Linux services checked:  nsrexecd, nsrd  (configure below)
Windows services checked: nsrexecd (short name), NetWorker Remote Exec Service (display name)

Usage: python step5_service_check.py --client app-srv-42 --os Linux --user svc_backup --key ~/.ssh/id_rsa
"""

import argparse
import json
import sys
from step4_login import ssh_login, winrm_login, run_ssh_command, run_winrm_command


# ── Configure service names ────────────────────────────────────────────────
# Linux: systemd service names (what you pass to systemctl)
LINUX_SERVICES = [
    'nsrexecd',       # NetWorker client daemon (primary - always check)
    'nsrd',           # NetWorker server daemon (only present on NW server role)
]

# Windows: list of dicts with both short name and display name.
# Get-Service accepts EITHER -Name (short) OR -DisplayName.
# We try short name first, then display name as fallback.
WINDOWS_SERVICES = [
    {'name': 'nsrexecd',                    'display': 'NetWorker Remote Exec Service'},
    {'name': 'NetWorker',                   'display': 'Legato NetWorker'},
]
# ───────────────────────────────────────────────────────────────────────────


# ── Linux helpers ──────────────────────────────────────────────────────────

def check_linux_service(conn, service: str) -> str:
    """
    Returns 'running', 'stopped', or 'not_found'.
    Uses systemctl is-active first; falls back to service status for non-systemd.
    """
    # Primary: systemctl is-active returns exactly 'active' or 'inactive'/'failed'/etc
    stdout, stderr, rc = run_ssh_command(
        conn, f'systemctl is-active {service} 2>/dev/null'
    )
    text = stdout.strip().lower()
    if text == 'active':
        return 'running'
    if text in ('inactive', 'failed', 'activating', 'deactivating'):
        return 'stopped'

    # If systemctl is not available (non-systemd host), try legacy service command
    stdout2, stderr2, rc2 = run_ssh_command(
        conn, f'service {service} status 2>/dev/null; echo "EXIT:$?"'
    )
    combined = stdout2.lower()
    if 'running' in combined and 'not running' not in combined:
        return 'running'
    if rc2 == 0 and 'exit:0' in combined:
        return 'running'

    # Check whether the service unit exists at all
    _, _, exists_rc = run_ssh_command(
        conn,
        f'systemctl list-unit-files {service}.service 2>/dev/null | grep -q {service} '
        f'|| ls /etc/init.d/{service} 2>/dev/null'
    )
    if exists_rc != 0:
        return 'not_found'

    return 'stopped'


def restart_linux_service(conn, service: str) -> bool:
    """Restart a Linux service. Returns True if it comes up running."""
    # Try systemctl restart
    _, _, rc = run_ssh_command(conn, f'sudo systemctl restart {service} 2>/dev/null')
    if rc == 0:
        # Confirm it is now active
        stdout, _, _ = run_ssh_command(conn, f'systemctl is-active {service} 2>/dev/null')
        if stdout.strip().lower() == 'active':
            return True

    # Fallback: legacy init
    _, _, rc2 = run_ssh_command(conn, f'sudo service {service} restart 2>/dev/null')
    if rc2 == 0:
        # Verify
        stdout2, _, _ = run_ssh_command(conn, f'service {service} status 2>/dev/null')
        if 'running' in stdout2.lower() and 'not running' not in stdout2.lower():
            return True

    return False


# ── Windows helpers ────────────────────────────────────────────────────────

def check_windows_service(session, svc_entry: dict) -> str:
    """
    Returns 'running', 'stopped', or 'not_found'.
    Tries short service name first, then display name.
    svc_entry: {'name': 'nsrexecd', 'display': 'NetWorker Remote Exec Service'}
    """
    short_name   = svc_entry.get('name', '')
    display_name = svc_entry.get('display', '')

    # Try by short name first
    if short_name:
        ps = (f'$s = Get-Service -Name "{short_name}" -ErrorAction SilentlyContinue; '
              f'if ($s) {{ $s.Status }} else {{ "NOT_FOUND" }}')
        stdout, _, rc = run_winrm_command(session, ps)
        result = stdout.strip()
        if result == 'Running':
            return 'running'
        if result == 'Stopped':
            return 'stopped'

    # Fallback: search by display name
    if display_name:
        ps = (f'$s = Get-Service -DisplayName "{display_name}" -ErrorAction SilentlyContinue; '
              f'if ($s) {{ $s.Status }} else {{ "NOT_FOUND" }}')
        stdout, _, rc = run_winrm_command(session, ps)
        result = stdout.strip()
        if result == 'Running':
            return 'running'
        if result == 'Stopped':
            return 'stopped'

    return 'not_found'


def restart_windows_service(session, svc_entry: dict) -> bool:
    """Restart a Windows service by short name or display name."""
    short_name   = svc_entry.get('name', '')
    display_name = svc_entry.get('display', '')

    # Try short name
    for identifier, flag in [(short_name, '-Name'), (display_name, '-DisplayName')]:
        if not identifier:
            continue
        ps = (f'try {{'
              f'  Start-Service {flag} "{identifier}" -ErrorAction Stop; '
              f'  (Get-Service {flag} "{identifier}" -ErrorAction SilentlyContinue).Status'
              f'}} catch {{ "FAILED" }}')
        stdout, _, rc = run_winrm_command(session, ps)
        if 'Running' in stdout:
            return True

    return False


def _get_svc_label(svc_entry) -> str:
    """Return a human-readable label for the service entry (handles both str and dict)."""
    if isinstance(svc_entry, dict):
        return svc_entry.get('name') or svc_entry.get('display', '?')
    return str(svc_entry)


# ── Main check_services function ──────────────────────────────────────────

def check_services(ticket: dict, username: str, **auth_kwargs) -> dict:
    """
    Check all services for a ticket.

    Reuses ticket['_conn'] if present (set by step4 login).
    Falls back to establishing a new connection if called standalone.
    """
    hostname = ticket['client']
    os_type  = ticket.get('os_type', 'Linux')

    # ── Get or open connection ──────────────────────────────────────────
    conn      = ticket.get('_conn')
    conn_type = ticket.get('_conn_type', 'ssh' if os_type == 'Linux' else 'winrm')
    opened_here = False

    if not conn:
        print(f"[STEP 5] No existing connection for {hostname} - opening new one...")
        if os_type == 'Linux':
            conn = ssh_login(hostname, username, **auth_kwargs)
            conn_type = 'ssh'
        else:
            conn = winrm_login(
                hostname, username,
                auth_method  = auth_kwargs.get('winrm_auth', 'ntlm'),
                password     = auth_kwargs.get('password'),
                use_ssl      = auth_kwargs.get('use_ssl', False),
                cert_pem     = auth_kwargs.get('cert_pem'),
                cert_key_pem = auth_kwargs.get('cert_key_pem'),
            )
            conn_type = 'winrm'
        opened_here = True

    if not conn:
        ticket['step5_status'] = 'FAIL'
        ticket['step5_note']   = f'Could not connect to {hostname} for service check'
        return ticket

    # Store back in ticket so step6 can reuse it
    ticket['_conn']      = conn
    ticket['_conn_type'] = conn_type

    # ── Service list ───────────────────────────────────────────────────
    if os_type == 'Linux':
        services = LINUX_SERVICES
    else:
        # Normalise: if config has plain strings, wrap them
        raw = WINDOWS_SERVICES
        services = [
            s if isinstance(s, dict) else {'name': s, 'display': s}
            for s in raw
        ]

    results = []
    overall = 'PASS'

    for svc in services:
        label = _get_svc_label(svc)

        if os_type == 'Linux':
            state = check_linux_service(conn, svc)
        else:
            state = check_windows_service(conn, svc)

        if state == 'running':
            print(f"[STEP 5] + {label} is running on {hostname}")
            results.append({'service': label, 'state': 'running', 'action': 'none'})

        elif state == 'stopped':
            print(f"[STEP 5] ~ {label} is STOPPED on {hostname} - attempting restart...")
            if os_type == 'Linux':
                ok = restart_linux_service(conn, svc)
            else:
                ok = restart_windows_service(conn, svc)

            if ok:
                print(f"[STEP 5] + {label} restarted successfully")
                results.append({'service': label, 'state': 'restarted', 'action': 'restarted'})
            else:
                print(f"[STEP 5] x Failed to restart {label}")
                results.append({'service': label, 'state': 'restart_failed', 'action': 'restart_failed'})
                overall = 'FAIL'

        else:  # not_found
            print(f"[STEP 5] ~ {label} not found on {hostname} - skipping")
            results.append({'service': label, 'state': 'not_found', 'action': 'skipped'})

    # Close connection only if we opened it here (standalone CLI use)
    if opened_here:
        if conn_type == 'ssh' and hasattr(conn, 'close'):
            conn.close()
        ticket.pop('_conn', None)
        ticket.pop('_conn_type', None)

    ticket['step5_status']   = overall
    ticket['step5_services'] = results

    restarted = [r['service'] for r in results if r['action'] == 'restarted']
    failed    = [r['service'] for r in results if r['action'] == 'restart_failed']
    not_found = [r['service'] for r in results if r['action'] == 'skipped']
    note_parts = []
    if restarted:  note_parts.append(f"Restarted: {', '.join(restarted)}")
    if failed:     note_parts.append(f"Restart failed: {', '.join(failed)}")
    if not_found:  note_parts.append(f"Not found: {', '.join(not_found)}")
    if not note_parts: note_parts.append('All services OK')
    ticket['step5_note'] = ' | '.join(note_parts)

    return ticket


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Step 5: Service check & restart')
    parser.add_argument('--client',   help='Single client hostname')
    parser.add_argument('--os',       help='Windows or Linux', default='Linux')
    parser.add_argument('--user',     required=True, help='Service account username')
    parser.add_argument('--key',      help='SSH private key path')
    parser.add_argument('--password', help='Password')
    parser.add_argument('--file',     help='Tickets JSON', default='parsed_tickets.json')
    parser.add_argument('--output',   help='Output JSON', default='parsed_tickets.json')
    args = parser.parse_args()

    if args.client:
        ticket = {'ticket_id': 'TEST', 'client': args.client, 'os_type': args.os}
        check_services(ticket, args.user,
                       auth_method='key_file' if args.key else 'password',
                       password=args.password, key_path=args.key)
        print(f"Status: {ticket['step5_status']} - {ticket['step5_note']}")
    else:
        with open(args.file) as f:
            tickets = json.load(f)
        for t in tickets:
            if t.get('step4_status') == 'PASS':
                check_services(t, args.user,
                               auth_method='key_file' if args.key else 'password',
                               password=args.password, key_path=args.key)
            else:
                t['step5_status'] = 'SKIPPED'
                t['step5_note']   = 'Skipped - login failed'
        with open(args.output, 'w') as f:
            json.dump(tickets, f, indent=2)
        print(f"[STEP 5] Saved to {args.output}")
