"""
NetWorker Backup Remediation — CLI Orchestrator
Runs all 8 steps in sequence for all tickets in a CSV export.

Usage examples:
    # Password
    python run_remediation.py --file tickets.csv --user svc_backup --password SECRET

    # SSH key file
    python run_remediation.py --file tickets.csv --user svc_backup --auth-method key_file --key-path ~/.ssh/id_rsa

    # SSH agent (keys pre-loaded via ssh-add)
    python run_remediation.py --file tickets.csv --user svc_backup --auth-method agent

    # PAM / LDAP / RADIUS / TACACS+ (password sent over SSH, handled server-side)
    python run_remediation.py --file tickets.csv --user svc_backup --auth-method pam --password SECRET

    # GSSAPI/Kerberos SSH (run kinit first)
    python run_remediation.py --file tickets.csv --user svc_backup --auth-method gssapi

    # Jump/bastion host
    python run_remediation.py --file tickets.csv --user svc_backup --auth-method jump_host \\
        --jump-host bastion.corp.com --jump-password JPASS --password SECRET

    # HashiCorp Vault OTP
    python run_remediation.py --file tickets.csv --user svc_backup --auth-method vault \\
        --vault-addr https://vault:8200 --vault-token s.xxxx --vault-role backup-role

    # Windows WinRM NTLM
    python run_remediation.py --file tickets.csv --user DOMAIN\\svc --password SECRET --winrm-auth ntlm

    # Windows WinRM Kerberos (run kinit first)
    python run_remediation.py --file tickets.csv --user svc@DOMAIN --winrm-auth kerberos

    # Dry run (skips actual backup retrigger)
    python run_remediation.py --file tickets.csv --user svc_backup --password SECRET --dry-run

Output:
    remediation_results_<timestamp>.json
    close_notes_<timestamp>.csv
    close_notes_<timestamp>.txt
"""

import argparse
import json
import sys
from datetime import datetime

from step1_parse_ticket     import parse_from_csv
from step2_reachability     import check_tickets   as step2
from step3_identify_os      import identify_tickets as step3
from step4_login            import login
from step5_service_check    import check_services
from step6_disk_check       import check_disk
from step7_retrigger_backup import retrigger_backup
from step8_close_notes      import generate_close_notes


def run_pipeline(tickets: list[dict], username: str,
                 auth_kwargs: dict, dry_run: bool = False) -> list[dict]:
    """
    Execute the full 8-step remediation pipeline.
    auth_kwargs is passed directly to login/check_services/check_disk/retrigger_backup.
    """
    print(f"\n{'='*60}")
    print(f"NetWorker Backup Remediation Pipeline")
    print(f"Tickets     : {len(tickets)}")
    print(f"User        : {username}")
    print(f"Auth method : {auth_kwargs.get('auth_method','password')} "
          f"(WinRM: {auth_kwargs.get('winrm_auth','ntlm')})")
    print(f"Dry run     : {dry_run}")
    print(f"{'='*60}\n")

    # Step 2: Reachability (batch ping all clients)
    print("\n--- STEP 2: Reachability Check ---")
    tickets = step2(tickets)

    # Step 3: OS Identification (batch port probe)
    print("\n--- STEP 3: OS Identification ---")
    tickets = step3(tickets)

    # Steps 4–7: Per-ticket
    for t in tickets:
        tid = t['ticket_id']

        if not t.get('reachable', True):
            print(f"\n[{tid}] SKIPPING — host unreachable")
            for s in ['step4', 'step5', 'step6', 'step7']:
                t[f'{s}_status'] = 'SKIPPED'
                t[f'{s}_note']   = 'Skipped — host unreachable'
            continue

        print(f"\n{'─'*55}")
        print(f"[{tid}]  {t['client']}  ({t['os_type']})")
        print(f"{'─'*55}")

        # Step 4: Login
        print("\n--- STEP 4: Login ---")
        login(t, username, **auth_kwargs)
        t.pop('_conn', None)   # connection object is not JSON-serialisable

        if t.get('step4_status') != 'PASS':
            print(f"[{tid}] Login failed — skipping steps 5–7")
            for s in ['step5', 'step6', 'step7']:
                t[f'{s}_status'] = 'SKIPPED'
                t[f'{s}_note']   = 'Skipped — login failed'
            continue

        # Step 5: Service check & restart
        print("\n--- STEP 5: Service Check ---")
        check_services(t, username, **auth_kwargs)

        # Step 6: Disk space
        print("\n--- STEP 6: Disk Space Check ---")
        check_disk(t, username, **auth_kwargs)

        # Step 7: Retrigger backup
        if t.get('step5_status') == 'FAIL':
            print(f"[{tid}] Service restart failed — skipping retrigger")
            t['step7_status'] = 'SKIPPED'
            t['step7_note']   = 'Skipped — service restart failed'
        else:
            print("\n--- STEP 7: Retrigger Backup ---")
            retrigger_backup(t, username, dry_run=dry_run, **auth_kwargs)

    # Step 8: Generate close notes for all tickets
    print(f"\n{'='*60}")
    print("--- STEP 8: Close Notes ---")
    tickets = generate_close_notes(tickets)

    return tickets


def print_summary(tickets: list[dict]):
    print(f"\n{'='*60}")
    print("FINAL SUMMARY")
    print(f"{'='*60}")
    print(f"{'Ticket':<15} {'Client':<32} {'Result'}")
    print(f"{'-'*65}")
    for t in tickets:
        s7 = t.get('step7_status', '')
        if not t.get('reachable', True):
            result = '🔴 Unreachable'
        elif t.get('step4_status') == 'FAIL':
            result = '🔴 Login failed'
        elif s7 == 'PASS' and t.get('step6_status') != 'RED':
            result = '✅ Remediated'
        elif s7 == 'PASS' and t.get('step6_status') == 'RED':
            result = '⚠  Partial — disk low'
        elif s7 == 'FAIL':
            result = '✗  Retrigger failed'
        else:
            result = f'— {s7 or "incomplete"}'
        print(f"{t['ticket_id']:<15} {t['client']:<32} {result}")
    print(f"{'='*60}")


if __name__ == '__main__':
    p = argparse.ArgumentParser(
        description='NetWorker Backup Remediation — CLI Orchestrator',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    # Input
    p.add_argument('--file',         required=True, help='ServiceNow CSV export or parsed JSON')
    p.add_argument('--user',         required=True, help='Service account username')

    # Auth method (SSH / Linux)
    p.add_argument('--auth-method',  default='password',
                   choices=['password','key_file','key_text','agent','gssapi',
                            'pam','ldap','radius','tacacs','jump_host','vault'],
                   help='SSH auth method for Linux clients (default: password)')
    p.add_argument('--password',     help='Password or key passphrase')
    p.add_argument('--key-path',     help='SSH private key file path')
    p.add_argument('--key-text',     help='SSH private key content as string')

    # Jump host
    p.add_argument('--jump-host',    help='Bastion/jump hostname')
    p.add_argument('--jump-user',    help='Jump host username (defaults to --user)')
    p.add_argument('--jump-password',help='Jump host password')
    p.add_argument('--jump-key',     help='Jump host SSH key path')

    # Vault
    p.add_argument('--vault-addr',   help='HashiCorp Vault server URL')
    p.add_argument('--vault-token',  help='Vault token')
    p.add_argument('--vault-role',   help='Vault SSH role name')

    # WinRM (Windows)
    p.add_argument('--winrm-auth',   default='ntlm',
                   choices=['ntlm','basic','kerberos','credssp','certificate'],
                   help='WinRM transport for Windows clients (default: ntlm)')
    p.add_argument('--ssl',          action='store_true', help='WinRM HTTPS (port 5986)')
    p.add_argument('--cert-pem',     help='WinRM client cert PEM path')
    p.add_argument('--cert-key-pem', help='WinRM client cert key PEM path')

    # Pipeline options
    p.add_argument('--dry-run',      action='store_true', help='Skip actual backup retrigger')
    p.add_argument('--output-dir',   default='.', help='Directory for output files')
    args = p.parse_args()

    # Build auth_kwargs dict — passed through to every step
    auth_kwargs = dict(
        auth_method   = args.auth_method,
        password      = args.password,
        key_path      = args.key_path,
        key_text      = args.key_text,
        jump_host     = args.jump_host,
        jump_user     = args.jump_user,
        jump_password = args.jump_password,
        jump_key_path = args.jump_key,
        vault_addr    = args.vault_addr,
        vault_token   = args.vault_token,
        vault_role    = args.vault_role,
        winrm_auth    = args.winrm_auth,
        use_ssl       = args.ssl,
        cert_pem      = args.cert_pem,
        cert_key_pem  = args.cert_key_pem,
    )

    # Load tickets
    if args.file.endswith('.json'):
        with open(args.file) as f:
            tickets = json.load(f)
    else:
        tickets = parse_from_csv(args.file)   # Step 1

    # Run pipeline
    tickets = run_pipeline(tickets, args.user, auth_kwargs, dry_run=args.dry_run)

    # Save outputs
    ts       = datetime.now().strftime('%Y%m%d_%H%M%S')
    json_out = f"{args.output_dir}/remediation_results_{ts}.json"
    csv_out  = f"{args.output_dir}/close_notes_{ts}.csv"
    txt_out  = f"{args.output_dir}/close_notes_{ts}.txt"

    with open(json_out, 'w') as f:
        json.dump(tickets, f, indent=2)

    generate_close_notes(tickets, output_format='csv',  output_file=csv_out)
    generate_close_notes(tickets, output_format='text', output_file=txt_out)

    print_summary(tickets)
    print(f"\nOutput files:")
    print(f"  JSON : {json_out}")
    print(f"  CSV  : {csv_out}")
    print(f"  Text : {txt_out}")
