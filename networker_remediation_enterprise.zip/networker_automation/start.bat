@echo off
REM NetWorker Remediation Hub - Windows startup script
cd /d "%~dp0"
echo ========================================
echo  NetWorker Remediation Hub
echo ========================================
python -m pip install flask flask-cors paramiko pywinrm --quiet
echo Starting API server on http://localhost:5050
echo Open dashboard.html in your browser OR visit http://localhost:5050
echo.
python dashboard_api.py
pause
