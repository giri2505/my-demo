# NetWorker Backup Remediation Hub

Enterprise-grade automation for NetWorker backup failures with AI intelligence.

## Quick Start

### Linux / macOS
```bash
chmod +x start.sh && ./start.sh
```

### Windows
```
Double-click start.bat
```

Then open **http://localhost:5050** in your browser.

---

## Authentication Setup

### Linux — SSH Key File (recommended)

Set up a service account with a key on all managed Linux hosts:
```bash
ssh-keygen -t ed25519 -f ~/.ssh/id_ed25519 -N ""
ssh-copy-id -i ~/.ssh/id_ed25519.pub svc_networker@<target-host>
```

In **Settings → Linux SSH Auth**:
- Auth Method: `SSH Key File`
- Key Path: `/home/svc_networker/.ssh/id_ed25519`

### Linux — Prompt (password entered at run time)

In **Settings → Linux SSH Auth**:
- Auth Method: `Prompt — enter password live at run time`

When a ticket runs, the pipeline pauses and a password dialog appears in the
dashboard. Enter the password — the run resumes automatically. The password
is never stored anywhere.

### Windows — PAM / WinRM

Your PAM-managed RDP account works over WinRM (port 5985, not 3389).
One-time setup on each Windows host (or via GPO):
```powershell
winrm quickconfig
winrm set winrm/config/service/auth @{Negotiate="true"}
```

In **Settings → Windows WinRM**:
- Transport: `NTLM` (for domain accounts) or `Kerberos` (AD SSO)

For prompt mode: select `Prompt` — same live-password dialog as Linux.

---

## AI Intelligence (Optional)

### Azure AI Foundry (primary)

In **Settings → AI Intelligence → Azure AI Foundry**:
1. **Endpoint URL** — from your Foundry project → Deployments page
2. **Deployment Name** — e.g. `gpt-4o`, `Phi-4`, `Mistral-Large-2407`
3. **API Key** — from Foundry Keys page
4. Click **✦ Test AI Connection** to verify

Supported endpoint formats:
- Azure OpenAI: `https://<resource>.openai.azure.com/`
- Foundry managed compute: `https://<project>.inference.ml.azure.com/`
- Foundry serverless (MaaS): `https://<project>.inference.ai.azure.com/`

### Anthropic Claude (fallback)

Fill in the **Anthropic API Key** field — used automatically if Azure is not configured.

### What AI adds

| Feature | Trigger | Output |
|---|---|---|
| Pre-triage | Auto before step 2 | Risk score 1-10, priority, predicted cause |
| Root cause analysis | Auto after step 8 | Confirmed cause, confidence, 3 preventive actions |
| AI close notes | Auto after RCA | Natural-language ServiceNow paragraph |
| Manual steps | When automation fails | Ordered L2 troubleshooting checklist |
| Pattern detection | AI Insights tab | Cross-ticket patterns, systemic risk |

All AI features are optional — automation works identically without them.

---

## Files

| File | Purpose |
|---|---|
| `dashboard_api.py` | Flask REST API backend (the engine) |
| `dashboard.html` | Web dashboard UI |
| `ai_analysis.py` | AI Intelligence layer (Azure Foundry + Anthropic) |
| `step1_parse_ticket.py` | Parse ServiceNow CSV export |
| `step2_reachability.py` | ICMP ping check |
| `step3_identify_os.py` | Detect Windows vs Linux |
| `step4_login.py` | SSH key / prompt / WinRM login |
| `step5_service_check.py` | Check and restart backup services |
| `step6_disk_check.py` | Disk space check |
| `step7_retrigger_backup.py` | NetWorker backup retrigger |
| `step8_close_notes.py` | Generate close notes |
| `run_remediation.py` | CLI orchestrator (headless / no dashboard) |

---

## CLI Usage (headless)

```bash
# SSH key file
python3 run_remediation.py \
    --file tickets.csv \
    --user svc_networker \
    --auth-method key_file \
    --key-path ~/.ssh/id_ed25519

# Windows WinRM NTLM
python3 run_remediation.py \
    --file tickets.csv \
    --user DOMAIN\\svc_networker \
    --password "YourPassword" \
    --winrm-auth ntlm

# Dry run
python3 run_remediation.py --file tickets.csv --user svc_networker \
    --auth-method key_file --key-path ~/.ssh/id_ed25519 --dry-run
```

Note: `prompt` auth is dashboard-only (CLI will not pause for input).
