"""
Step 4: Service Account Login
============================
Enterprise authentication — two primary paths:

 ── LINUX: Service Account via SSH Key ───────────────────────────────────────
  key_file   SSH private key file on disk  (RECOMMENDED — default for Linux)
             Service account (e.g. svc_networker) with authorised_keys set up
             on all managed Linux hosts.
  key_text   Paste private key content directly (for secrets-manager injection)
  agent      SSH Agent — keys loaded via ssh-add (CI/CD pipelines)
  gssapi     GSSAPI/Kerberos — AD-joined Linux, run kinit first
  jump_host  Bastion/jump host tunnel — for segmented networks
  vault      HashiCorp Vault SSH OTP / signed cert

 ── WINDOWS: PAM / WinRM via RDP-capable service account ─────────────────────
  ntlm       NTLM over WinRM (default) — works without AD, firewall port 5985
  kerberos   Kerberos / AD SSO — run kinit svc@DOMAIN.COM first
  credssp    CredSSP — for double-hop (delegates creds to next hop)
  certificate Client certificate (advanced — requires cert enrollment on hosts)

  NOTE on PAM + RDP accounts:
    WinRM (port 5985/5986) is the automation transport — NOT RDP (3389).
    Your PAM-managed RDP service account (e.g. DOMAIN\\svc_networker) works
    here AS LONG AS the account has WinRM access granted via GPO or local
    policy:  winrm set winrm/config/service/auth @{Negotiate="true"}
    The same credentials that grant RDP work for WinRM with ntlm/kerberos.

Dependencies:
    pip install paramiko pywinrm
    pip install pywinrm[kerberos]   # kerberos WinRM
    pip install pywinrm[credssp]    # CredSSP WinRM
    pip install hvac                # HashiCorp Vault
"""

import argparse
import io
import json
import os
import sys
from typing import Optional, Tuple


# ─────────────────────────────────────────────────────────────────────────────
# Utilities
# ─────────────────────────────────────────────────────────────────────────────

def _paramiko():
    try:
        import paramiko
        return paramiko
    except ImportError:
        print("[STEP 4] ERROR: paramiko not installed — run: pip install paramiko")
        sys.exit(1)


def _load_key_from_text(key_text: str, passphrase: str = None):
    """Load a paramiko private key from a raw string. Auto-detects key type."""
    pm = _paramiko()
    buf = io.StringIO(key_text.strip())
    for loader in [pm.RSAKey, pm.Ed25519Key, pm.ECDSAKey, pm.DSSKey]:
        try:
            buf.seek(0)
            kw = {'file_obj': buf}
            if passphrase:
                kw['password'] = passphrase
            return loader.from_private_key(**kw)
        except Exception:
            continue
    print("[STEP 4] ✗ Could not parse key text — check format (RSA/Ed25519/ECDSA/DSS)")
    return None


def _make_ssh_client():
    pm = _paramiko()
    c = pm.SSHClient()
    c.set_missing_host_key_policy(pm.AutoAddPolicy())
    return c


# ─────────────────────────────────────────────────────────────────────────────
# SSH (Linux)
# ─────────────────────────────────────────────────────────────────────────────

def ssh_login(hostname: str, username: str,
              auth_method: str = 'password',
              password: str = None,
              key_path: str = None,
              key_text: str = None,
              port: int = 22,
              jump_host: str = None,
              jump_user: str = None,
              jump_password: str = None,
              jump_key_path: str = None,
              vault_addr: str = None,
              vault_token: str = None,
              vault_role: str = None,
              **_) -> Optional[object]:
    """
    Connect to a Linux host via SSH.
    Returns paramiko SSHClient on success, None on failure.
    """
    pm = _paramiko()
    client = _make_ssh_client()

    try:
        base = dict(hostname=hostname, port=port, username=username, timeout=15)

        # ── password ──────────────────────────────────────────────────────
        if auth_method == 'password':
            if not password:
                print("[STEP 4] ✗ password required"); return None
            base.update(password=password, look_for_keys=False, allow_agent=False)

        # ── key_file ──────────────────────────────────────────────────────
        elif auth_method == 'key_file':
            if not key_path:
                print("[STEP 4] ✗ key_path required"); return None
            if not os.path.exists(key_path):
                print(f"[STEP 4] ✗ Key file not found: {key_path}"); return None
            kw = dict(key_filename=key_path, look_for_keys=False, allow_agent=False)
            if password:
                kw['passphrase'] = password
            base.update(kw)

        # ── key_text (paste private key directly) ─────────────────────────
        elif auth_method == 'key_text':
            if not key_text:
                print("[STEP 4] ✗ key_text required"); return None
            pkey = _load_key_from_text(key_text, passphrase=password)
            if not pkey:
                return None
            base.update(pkey=pkey, look_for_keys=False, allow_agent=False)

        # ── SSH agent ─────────────────────────────────────────────────────
        elif auth_method == 'agent':
            # Run: ssh-add ~/.ssh/id_rsa   before starting the dashboard
            base.update(allow_agent=True, look_for_keys=True)

        # ── GSSAPI / Kerberos over SSH ────────────────────────────────────
        elif auth_method == 'gssapi':
            # Run: kinit svc_backup@CORP.COM   before starting the dashboard
            base.update(gss_auth=True, gss_kex=True,
                        allow_agent=False, look_for_keys=False)

        # ── PAM ───────────────────────────────────────────────────────────
        # PAM runs server-side. SSH sees it as password or keyboard-interactive.
        # Covers: LDAP, RADIUS, TACACS+, OTP, smart card via PAM modules.
        elif auth_method in ('pam', 'ldap', 'radius', 'tacacs'):
            if not password:
                print(f"[STEP 4] ✗ password required for {auth_method}"); return None
            if auth_method != 'pam':
                print(f"[STEP 4] Note: {auth_method.upper()} auth is handled server-side "
                      "via PAM/sssd — sending password over SSH.")
            base.update(password=password, look_for_keys=False, allow_agent=False)

        # ── Jump / Bastion host ───────────────────────────────────────────
        elif auth_method == 'jump_host':
            if not jump_host:
                print("[STEP 4] ✗ jump_host required"); return None
            return _ssh_via_jump(
                target_host=hostname, target_user=username, target_port=port,
                jump_host=jump_host,
                jump_user=jump_user or username,
                jump_password=jump_password or password,
                jump_key_path=jump_key_path or key_path,
                target_password=password,
                target_key_path=key_path,
            )

        # ── HashiCorp Vault OTP ───────────────────────────────────────────
        elif auth_method == 'vault':
            return _vault_ssh_login(
                hostname=hostname, username=username, port=port,
                vault_addr=vault_addr, vault_token=vault_token, vault_role=vault_role,
            )

        else:
            print(f"[STEP 4] ✗ Unknown SSH auth_method: {auth_method}"); return None

        client.connect(**base)
        print(f"[STEP 4] ✓ SSH OK: {username}@{hostname}:{port} [{auth_method}]")
        return client

    except pm.AuthenticationException:
        print(f"[STEP 4] ✗ SSH auth failed: {username}@{hostname} [{auth_method}]")
    except pm.SSHException as e:
        print(f"[STEP 4] ✗ SSH error {hostname}: {e}")
    except Exception as e:
        print(f"[STEP 4] ✗ Cannot connect to {hostname}: {e}")
    return None


def _ssh_via_jump(target_host, target_user, target_port,
                  jump_host, jump_user,
                  jump_password=None, jump_key_path=None,
                  target_password=None, target_key_path=None):
    """Connect to target through a bastion/jump host."""
    pm = _paramiko()

    # 1. Connect to jump host
    jump = _make_ssh_client()
    jkw = dict(hostname=jump_host, username=jump_user, timeout=15)
    if jump_key_path:
        jkw['key_filename'] = jump_key_path
    elif jump_password:
        jkw['password'] = jump_password
    try:
        jump.connect(**jkw)
        print(f"[STEP 4] ✓ Jump host {jump_host} connected")
    except Exception as e:
        print(f"[STEP 4] ✗ Jump host {jump_host} failed: {e}"); return None

    # 2. Open tunnel through jump host to target
    channel = jump.get_transport().open_channel(
        'direct-tcpip', (target_host, target_port), ('127.0.0.1', 0))

    # 3. Connect target through tunnel
    target = _make_ssh_client()
    tkw = dict(hostname=target_host, username=target_user, sock=channel, timeout=15)
    if target_key_path:
        tkw['key_filename'] = target_key_path
    elif target_password:
        tkw['password'] = target_password
    try:
        target.connect(**tkw)
        print(f"[STEP 4] ✓ SSH via jump {jump_host} → {target_host} OK")
        return target
    except Exception as e:
        print(f"[STEP 4] ✗ Target {target_host} via jump failed: {e}"); return None


def _vault_ssh_login(hostname, username, port, vault_addr, vault_token, vault_role):
    """Fetch Vault SSH OTP and use it to connect."""
    try:
        import hvac
    except ImportError:
        print("[STEP 4] ERROR: hvac not installed — run: pip install hvac"); return None
    try:
        vc = hvac.Client(url=vault_addr, token=vault_token)
        resp = vc.secrets.ssh.generate_ssh_credentials(
            name=vault_role, username=username, ip=hostname)
        otp = resp['data']['key']
        print(f"[STEP 4] Vault OTP obtained for {username}@{hostname}")
        return ssh_login(hostname, username, auth_method='password', password=otp, port=port)
    except Exception as e:
        print(f"[STEP 4] ✗ Vault SSH error: {e}"); return None


def run_ssh_command(client, command: str) -> Tuple[str, str, int]:
    """Execute a command over SSH. Returns (stdout, stderr, exit_code)."""
    _, stdout, stderr = client.exec_command(command, timeout=60)
    rc = stdout.channel.recv_exit_status()
    return stdout.read().decode().strip(), stderr.read().decode().strip(), rc


# ─────────────────────────────────────────────────────────────────────────────
# WinRM (Windows)
# ─────────────────────────────────────────────────────────────────────────────

def winrm_login(hostname: str, username: str,
                auth_method: str = 'ntlm',
                password: str = None,
                use_ssl: bool = False,
                cert_pem: str = None,
                cert_key_pem: str = None,
                **_) -> Optional[object]:
    """
    Connect to a Windows host via WinRM.
    auth_method: ntlm | basic | kerberos | credssp | certificate
    """
    try:
        import winrm
    except ImportError:
        print("[STEP 4] ERROR: pywinrm not installed — run: pip install pywinrm")
        sys.exit(1)

    scheme = 'https' if use_ssl else 'http'
    port   = 5986   if use_ssl else 5985
    url    = f'{scheme}://{hostname}:{port}/wsman'

    try:
        kw = dict(target=url, transport=auth_method, server_cert_validation='ignore')

        if auth_method in ('ntlm', 'basic'):
            if not password:
                print(f"[STEP 4] ✗ password required for WinRM/{auth_method}"); return None
            kw['auth'] = (username, password)

        elif auth_method == 'kerberos':
            # pip install pywinrm[kerberos]  +  kinit user@DOMAIN
            kw['auth'] = (username, '')
            print(f"[STEP 4] WinRM/Kerberos: ensure kinit ticket exists for {username}")

        elif auth_method == 'credssp':
            # pip install pywinrm[credssp]  — for double-hop credential delegation
            if not password:
                print("[STEP 4] ✗ password required for WinRM/CredSSP"); return None
            kw['auth'] = (username, password)

        elif auth_method == 'certificate':
            if not cert_pem or not cert_key_pem:
                print("[STEP 4] ✗ cert_pem + cert_key_pem required for WinRM/Certificate")
                return None
            kw.update(cert_pem=cert_pem, cert_key_pem=cert_key_pem, auth=('', ''))

        else:
            print(f"[STEP 4] ✗ Unknown WinRM auth_method: {auth_method}"); return None

        session = winrm.Session(**kw)
        r = session.run_cmd('echo connected')
        if r.status_code == 0:
            print(f"[STEP 4] ✓ WinRM OK: {username}@{hostname} [{auth_method}]")
            return session
        print(f"[STEP 4] ✗ WinRM test failed: {r.std_err.decode()}")
        return None

    except Exception as e:
        print(f"[STEP 4] ✗ WinRM error {hostname} [{auth_method}]: {e}")
        return None


def run_winrm_command(session, command: str, powershell: bool = True) -> Tuple[str, str, int]:
    """Run a command via WinRM. Returns (stdout, stderr, exit_code)."""
    r = session.run_ps(command) if powershell else session.run_cmd(command)
    return r.std_out.decode().strip(), r.std_err.decode().strip(), r.status_code


# ─────────────────────────────────────────────────────────────────────────────
# Unified dispatcher — called by all other steps
# ─────────────────────────────────────────────────────────────────────────────

def login(ticket: dict, username: str, **auth_kwargs) -> dict:
    """
    Login to ticket['client']. Dispatches to SSH or WinRM based on os_type.
    Connection stored in ticket['_conn'] (in-memory, never serialised to JSON).

    Key auth_kwargs:
        auth_method   SSH: password|key_file|key_text|agent|gssapi|pam|ldap|
                          radius|tacacs|jump_host|vault
        winrm_auth    WinRM: ntlm|basic|kerberos|credssp|certificate
        password      password or key passphrase
        key_path      path to SSH private key file
        key_text      raw SSH private key string (paste)
        jump_host     bastion hostname
        jump_user     bastion username
        jump_password bastion password
        jump_key_path bastion SSH key path
        vault_addr    Vault server URL
        vault_token   Vault token
        vault_role    Vault SSH role
        use_ssl       WinRM HTTPS (bool)
        cert_pem      WinRM cert path
        cert_key_pem  WinRM cert key path
    """
    hostname = ticket['client']
    os_type  = ticket.get('os_type', 'Linux')
    method   = auth_kwargs.get('auth_method', 'password')
    w_method = auth_kwargs.get('winrm_auth', 'ntlm')

    if os_type == 'Linux':
        conn  = ssh_login(hostname, username, **auth_kwargs)
        label = f"SSH/{method}"
    else:
        conn  = winrm_login(hostname, username,
                            auth_method=w_method,
                            password=auth_kwargs.get('password'),
                            use_ssl=auth_kwargs.get('use_ssl', False),
                            cert_pem=auth_kwargs.get('cert_pem'),
                            cert_key_pem=auth_kwargs.get('cert_key_pem'))
        label = f"WinRM/{w_method}"

    if conn:
        ticket['step4_status'] = 'PASS'
        ticket['step4_note']   = f"Logged in as {username} via {label}"
        ticket['_conn']        = conn
        ticket['_conn_type']   = 'ssh' if os_type == 'Linux' else 'winrm'
    else:
        ticket['step4_status'] = 'FAIL'
        ticket['step4_note']   = f"Login failed: {username}@{hostname} via {label}"

    return ticket


# ─────────────────────────────────────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == '__main__':
    p = argparse.ArgumentParser(
        description='Step 4: Login to backup client',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  Password:        --auth-method password    --user svc --password SECRET
  Key file:        --auth-method key_file    --user svc --key-path ~/.ssh/id_rsa
  Key paste:       --auth-method key_text    --user svc --key-text "$(cat ~/.ssh/id_rsa)"
  SSH Agent:       --auth-method agent       --user svc
  GSSAPI/Kerberos: --auth-method gssapi      --user svc@CORP.COM
  PAM:             --auth-method pam         --user svc --password SECRET
  LDAP:            --auth-method ldap        --user svc --password SECRET
  RADIUS:          --auth-method radius      --user svc --password SECRET
  TACACS+:         --auth-method tacacs      --user svc --password SECRET
  Jump host:       --auth-method jump_host   --user svc --password P --jump-host bastion.corp.com
  Vault OTP:       --auth-method vault       --user svc --vault-addr https://vault:8200 --vault-token TOK --vault-role backup
  WinRM NTLM:      --os Windows --winrm-auth ntlm       --user DOMAIN\\svc --password SECRET
  WinRM Kerberos:  --os Windows --winrm-auth kerberos   --user svc@DOMAIN
  WinRM CredSSP:   --os Windows --winrm-auth credssp    --user DOMAIN\\svc --password SECRET
        """
    )
    p.add_argument('--client')
    p.add_argument('--os',           default='Linux')
    p.add_argument('--user',         required=True)
    p.add_argument('--auth-method',  default='password',
                   choices=['password','key_file','key_text','agent','gssapi',
                            'pam','ldap','radius','tacacs','jump_host','vault'])
    p.add_argument('--password')
    p.add_argument('--key-path')
    p.add_argument('--key-text')
    p.add_argument('--winrm-auth',   default='ntlm',
                   choices=['ntlm','basic','kerberos','credssp','certificate'])
    p.add_argument('--ssl',          action='store_true')
    p.add_argument('--jump-host')
    p.add_argument('--jump-user')
    p.add_argument('--jump-password')
    p.add_argument('--jump-key')
    p.add_argument('--vault-addr')
    p.add_argument('--vault-token')
    p.add_argument('--vault-role')
    p.add_argument('--file')
    p.add_argument('--output', default='parsed_tickets.json')
    args = p.parse_args()

    kw = dict(
        auth_method=args.auth_method, password=args.password,
        key_path=args.key_path,       key_text=args.key_text,
        winrm_auth=args.winrm_auth,   use_ssl=args.ssl,
        jump_host=args.jump_host,     jump_user=args.jump_user,
        jump_password=args.jump_password, jump_key_path=args.jump_key,
        vault_addr=args.vault_addr,   vault_token=args.vault_token,
        vault_role=args.vault_role,
    )

    if args.file:
        with open(args.file) as f:
            tickets = json.load(f)
        for t in tickets:
            if t.get('reachable', True):
                login(t, args.user, **kw)
                t.pop('_conn', None)
        with open(args.output, 'w') as f:
            json.dump(tickets, f, indent=2)
        print(f"[STEP 4] Saved to {args.output}")
    elif args.client:
        t = {'client': args.client, 'os_type': args.os, 'ticket_id': 'TEST'}
        login(t, args.user, **kw)
        print(f"Result: {t['step4_status']} — {t['step4_note']}")
    else:
        p.print_help()
